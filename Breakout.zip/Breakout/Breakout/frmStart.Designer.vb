﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmStart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnTop = New System.Windows.Forms.Button()
        Me.btnLeft = New System.Windows.Forms.Button()
        Me.btnRight = New System.Windows.Forms.Button()
        Me.tbAns = New System.Windows.Forms.TextBox()
        Me.tmrMove = New System.Windows.Forms.Timer(Me.components)
        Me.btnB2 = New System.Windows.Forms.Button()
        Me.btnBot = New System.Windows.Forms.Button()
        Me.btnLPad = New System.Windows.Forms.Button()
        Me.btnRPad = New System.Windows.Forms.Button()
        Me.btnCPad = New System.Windows.Forms.Button()
        Me.btnB1 = New System.Windows.Forms.Button()
        Me.btnB3 = New System.Windows.Forms.Button()
        Me.btnB4 = New System.Windows.Forms.Button()
        Me.btnB5 = New System.Windows.Forms.Button()
        Me.btnB6 = New System.Windows.Forms.Button()
        Me.btnB7 = New System.Windows.Forms.Button()
        Me.btnB8 = New System.Windows.Forms.Button()
        Me.btnB9 = New System.Windows.Forms.Button()
        Me.PbT = New System.Windows.Forms.PictureBox()
        Me.pbOne = New System.Windows.Forms.PictureBox()
        CType(Me.PbT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbOne, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnTop
        '
        Me.btnTop.BackColor = System.Drawing.Color.Black
        Me.btnTop.Location = New System.Drawing.Point(1, 2)
        Me.btnTop.Name = "btnTop"
        Me.btnTop.Size = New System.Drawing.Size(789, 23)
        Me.btnTop.TabIndex = 0
        Me.btnTop.UseVisualStyleBackColor = False
        '
        'btnLeft
        '
        Me.btnLeft.BackColor = System.Drawing.Color.Black
        Me.btnLeft.Location = New System.Drawing.Point(0, 23)
        Me.btnLeft.Name = "btnLeft"
        Me.btnLeft.Size = New System.Drawing.Size(23, 641)
        Me.btnLeft.TabIndex = 1
        Me.btnLeft.UseVisualStyleBackColor = False
        '
        'btnRight
        '
        Me.btnRight.BackColor = System.Drawing.Color.Black
        Me.btnRight.Location = New System.Drawing.Point(767, 23)
        Me.btnRight.Name = "btnRight"
        Me.btnRight.Size = New System.Drawing.Size(23, 641)
        Me.btnRight.TabIndex = 2
        Me.btnRight.UseVisualStyleBackColor = False
        '
        'tbAns
        '
        Me.tbAns.BackColor = System.Drawing.SystemColors.Window
        Me.tbAns.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbAns.ForeColor = System.Drawing.Color.Blue
        Me.tbAns.Location = New System.Drawing.Point(515, 526)
        Me.tbAns.Name = "tbAns"
        Me.tbAns.ReadOnly = True
        Me.tbAns.Size = New System.Drawing.Size(218, 30)
        Me.tbAns.TabIndex = 5
        Me.tbAns.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.tbAns.Visible = False
        '
        'tmrMove
        '
        '
        'btnB2
        '
        Me.btnB2.BackColor = System.Drawing.Color.Yellow
        Me.btnB2.Location = New System.Drawing.Point(110, 31)
        Me.btnB2.Name = "btnB2"
        Me.btnB2.Size = New System.Drawing.Size(75, 35)
        Me.btnB2.TabIndex = 8
        Me.btnB2.Text = "Brick 2"
        Me.btnB2.UseVisualStyleBackColor = False
        '
        'btnBot
        '
        Me.btnBot.BackColor = System.Drawing.Color.Black
        Me.btnBot.Location = New System.Drawing.Point(0, 641)
        Me.btnBot.Name = "btnBot"
        Me.btnBot.Size = New System.Drawing.Size(789, 23)
        Me.btnBot.TabIndex = 9
        Me.btnBot.UseVisualStyleBackColor = False
        '
        'btnLPad
        '
        Me.btnLPad.BackColor = System.Drawing.Color.Red
        Me.btnLPad.Location = New System.Drawing.Point(297, 600)
        Me.btnLPad.Name = "btnLPad"
        Me.btnLPad.Size = New System.Drawing.Size(30, 24)
        Me.btnLPad.TabIndex = 10
        Me.btnLPad.UseVisualStyleBackColor = False
        '
        'btnRPad
        '
        Me.btnRPad.BackColor = System.Drawing.Color.Lime
        Me.btnRPad.Location = New System.Drawing.Point(351, 600)
        Me.btnRPad.Name = "btnRPad"
        Me.btnRPad.Size = New System.Drawing.Size(30, 24)
        Me.btnRPad.TabIndex = 11
        Me.btnRPad.UseVisualStyleBackColor = False
        '
        'btnCPad
        '
        Me.btnCPad.BackColor = System.Drawing.Color.Black
        Me.btnCPad.Location = New System.Drawing.Point(325, 600)
        Me.btnCPad.Name = "btnCPad"
        Me.btnCPad.Size = New System.Drawing.Size(30, 24)
        Me.btnCPad.TabIndex = 12
        Me.btnCPad.UseVisualStyleBackColor = False
        '
        'btnB1
        '
        Me.btnB1.BackColor = System.Drawing.Color.Lime
        Me.btnB1.Location = New System.Drawing.Point(29, 31)
        Me.btnB1.Name = "btnB1"
        Me.btnB1.Size = New System.Drawing.Size(75, 35)
        Me.btnB1.TabIndex = 13
        Me.btnB1.Text = "Brick 1"
        Me.btnB1.UseVisualStyleBackColor = False
        '
        'btnB3
        '
        Me.btnB3.BackColor = System.Drawing.Color.Red
        Me.btnB3.Location = New System.Drawing.Point(191, 31)
        Me.btnB3.Name = "btnB3"
        Me.btnB3.Size = New System.Drawing.Size(75, 35)
        Me.btnB3.TabIndex = 14
        Me.btnB3.Text = "Brick 3"
        Me.btnB3.UseVisualStyleBackColor = False
        '
        'btnB4
        '
        Me.btnB4.BackColor = System.Drawing.Color.Red
        Me.btnB4.Location = New System.Drawing.Point(272, 31)
        Me.btnB4.Name = "btnB4"
        Me.btnB4.Size = New System.Drawing.Size(75, 35)
        Me.btnB4.TabIndex = 15
        Me.btnB4.Text = "Brick 4"
        Me.btnB4.UseVisualStyleBackColor = False
        '
        'btnB5
        '
        Me.btnB5.BackColor = System.Drawing.Color.Yellow
        Me.btnB5.Location = New System.Drawing.Point(353, 31)
        Me.btnB5.Name = "btnB5"
        Me.btnB5.Size = New System.Drawing.Size(75, 35)
        Me.btnB5.TabIndex = 16
        Me.btnB5.Text = "Brick 5"
        Me.btnB5.UseVisualStyleBackColor = False
        '
        'btnB6
        '
        Me.btnB6.BackColor = System.Drawing.Color.Lime
        Me.btnB6.Location = New System.Drawing.Point(434, 31)
        Me.btnB6.Name = "btnB6"
        Me.btnB6.Size = New System.Drawing.Size(75, 35)
        Me.btnB6.TabIndex = 17
        Me.btnB6.Text = "Brick 6"
        Me.btnB6.UseVisualStyleBackColor = False
        '
        'btnB7
        '
        Me.btnB7.BackColor = System.Drawing.Color.Lime
        Me.btnB7.Location = New System.Drawing.Point(515, 31)
        Me.btnB7.Name = "btnB7"
        Me.btnB7.Size = New System.Drawing.Size(75, 35)
        Me.btnB7.TabIndex = 18
        Me.btnB7.Text = "Brick 7"
        Me.btnB7.UseVisualStyleBackColor = False
        '
        'btnB8
        '
        Me.btnB8.BackColor = System.Drawing.Color.Yellow
        Me.btnB8.Location = New System.Drawing.Point(596, 31)
        Me.btnB8.Name = "btnB8"
        Me.btnB8.Size = New System.Drawing.Size(75, 35)
        Me.btnB8.TabIndex = 19
        Me.btnB8.Text = "Brick 8"
        Me.btnB8.UseVisualStyleBackColor = False
        '
        'btnB9
        '
        Me.btnB9.BackColor = System.Drawing.Color.Red
        Me.btnB9.Location = New System.Drawing.Point(677, 31)
        Me.btnB9.Name = "btnB9"
        Me.btnB9.Size = New System.Drawing.Size(75, 35)
        Me.btnB9.TabIndex = 20
        Me.btnB9.Text = "Brick 9"
        Me.btnB9.UseVisualStyleBackColor = False
        '
        'PbT
        '
        Me.PbT.Image = Global.Breakout.My.Resources.Resources.explosion
        Me.PbT.Location = New System.Drawing.Point(370, 100)
        Me.PbT.Name = "PbT"
        Me.PbT.Size = New System.Drawing.Size(40, 40)
        Me.PbT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PbT.TabIndex = 21
        Me.PbT.TabStop = False
        Me.PbT.Visible = False
        '
        'pbOne
        '
        Me.pbOne.Image = Global.Breakout.My.Resources.Resources.red48
        Me.pbOne.Location = New System.Drawing.Point(360, 503)
        Me.pbOne.Name = "pbOne"
        Me.pbOne.Size = New System.Drawing.Size(12, 12)
        Me.pbOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbOne.TabIndex = 3
        Me.pbOne.TabStop = False
        '
        'frmStart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(792, 668)
        Me.Controls.Add(Me.btnB9)
        Me.Controls.Add(Me.btnB8)
        Me.Controls.Add(Me.btnB7)
        Me.Controls.Add(Me.btnB6)
        Me.Controls.Add(Me.btnB5)
        Me.Controls.Add(Me.btnB4)
        Me.Controls.Add(Me.btnB3)
        Me.Controls.Add(Me.btnB1)
        Me.Controls.Add(Me.btnCPad)
        Me.Controls.Add(Me.btnRPad)
        Me.Controls.Add(Me.btnLPad)
        Me.Controls.Add(Me.btnBot)
        Me.Controls.Add(Me.btnB2)
        Me.Controls.Add(Me.tbAns)
        Me.Controls.Add(Me.pbOne)
        Me.Controls.Add(Me.btnRight)
        Me.Controls.Add(Me.btnLeft)
        Me.Controls.Add(Me.btnTop)
        Me.Controls.Add(Me.PbT)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.Name = "frmStart"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form Start"
        CType(Me.PbT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbOne, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnTop As Button
    Friend WithEvents btnLeft As Button
    Friend WithEvents btnRight As Button
    Friend WithEvents pbOne As PictureBox
    Friend WithEvents tbAns As TextBox
    Friend WithEvents tmrMove As Timer
    Friend WithEvents btnB2 As Button
    Friend WithEvents btnBot As Button
    Friend WithEvents btnLPad As Button
    Friend WithEvents btnRPad As Button
    Friend WithEvents btnCPad As Button
    Friend WithEvents btnB1 As Button
    Friend WithEvents btnB3 As Button
    Friend WithEvents btnB4 As Button
    Friend WithEvents btnB5 As Button
    Friend WithEvents btnB6 As Button
    Friend WithEvents btnB7 As Button
    Friend WithEvents btnB8 As Button
    Friend WithEvents btnB9 As Button
    Friend WithEvents PbT As PictureBox
End Class
