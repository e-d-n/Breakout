﻿Public Class frmInfo

    Private Sub frmInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lbOne.Items.Add(" Press S to Start the Game")
        lbOne.Items.Add(" Press P to Pause the Game")
        lbOne.Items.Add(" Press ESC to End the Game")
        lbOne.Items.Add(" ")
        lbOne.Items.Add(" The Mouse Moves the Paddle Left & Right")
        lbOne.Items.Add(" The Cursor MUST stay inside the play area to")
        lbOne.Items.Add(" Move the Paddle Left & Right")
        lbOne.Items.Add(" ")
        lbOne.Items.Add(" Each Color of Paddle Sends the Ball in a Different")
        lbOne.Items.Add(" Direction Black Paddle Always Sends the Ball UP")
        lbOne.Items.Add(" ")
        lbOne.Items.Add(" Score is Based on Time")
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        frmStart.Show()
        Hide()
    End Sub
    Public Sub frmInfo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
        'Form Property KeyPreview needs to be set to True
        '=================================================

        If Asc(e.KeyChar) = 27 Then

            Const message As String = "YES" & "   Exit Program" + vbCrLf + vbNewLine + "NO" & "     Do Not EXIT"
            Const caption As String = "Exit OR Return"

            Dim result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                Application.Exit()
            ElseIf result = DialogResult.No Then
                Return
            End If
        End If

    End Sub
End Class