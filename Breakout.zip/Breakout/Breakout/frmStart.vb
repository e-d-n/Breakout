﻿Imports System.Threading

Public Class frmStart

    Dim count As Integer = 0
    Dim rndNUM As Integer = 0

    Dim spA As Integer = 1
    Dim spC As Integer = 1
    Dim spE As Integer = 1

    Dim endTime As Double
    Dim nowTime As Double

    Dim stopWatch As Stopwatch = New Stopwatch
    Dim ts As TimeSpan = stopWatch.Elapsed
    Dim elapsedTime As String

    Private Sub frmStart_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        Cursor.Clip = New Rectangle(Me.Location, Me.Size)
        btnLPad.Left = e.X
        btnCPad.Left = e.X + 28
        btnRPad.Left = e.X + 56
    End Sub

    Public Function Fire() As Integer
        'endTime = CDbl(DateTime.Now.AddSeconds(2).ToString("ss")
        endTime = DateTime.Now.Second
        endTime += 2.0
        Return CInt(endTime)
    End Function

    Private Sub tmrMove_Tick(sender As Object, e As EventArgs) Handles tmrMove.Tick

        'nowTime = CDbl(DateTime.Now.ToString("ss"))
        nowTime = DateTime.Now.Second
        If nowTime > endTime Then
            PbT.Visible = False
        End If

        If btnB1.Visible = False And btnB2.Visible = False And btnB3.Visible = False And btnB4.Visible = False _
        And btnB5.Visible = False And btnB6.Visible = False And btnB7.Visible = False And btnB8.Visible = False _
        And btnB9.Visible = False Then
            pbOne.Top = 300
            PbT.Visible = False
            tbAns.Visible = True

            stopWatch.Stop()
            ts = stopWatch.Elapsed
            elapsedTime = String.Format("{0:0}" & " Min & " & "{1:00}" & " Sec", ts.Minutes, ts.Seconds)
            tbAns.Text = elapsedTime

            count = 0
            tmrMove.Stop()
            MsgBox("You Win")
            stopWatch.Reset()
            '================
            tbAns.Visible = False
            frmStart_Load(e, e)

        End If

        If count = 0 Then
            pbOne.Top += 4
        End If

        If pbOne.Bounds.IntersectsWith(btnLPad.Bounds) Then
            rndNUM = 1
            count = 1
        End If
        If pbOne.Bounds.IntersectsWith(btnRight.Bounds) Then
            rndNUM = 2
        End If

        If pbOne.Bounds.IntersectsWith(btnLeft.Bounds) Then
            rndNUM = 3
        End If

        If pbOne.Bounds.IntersectsWith(btnCPad.Bounds) Then
            rndNUM = 4
            count = 1
        End If

        If pbOne.Bounds.IntersectsWith(btnRPad.Bounds) Then
            spA += 1
            If ((spA Mod 2) = 0) Then
                rndNUM = 5
            Else
                rndNUM = 6
            End If
            count = 1
        End If

        If pbOne.Bounds.IntersectsWith(btnTop.Bounds) Then
            spE += 1
            If ((spE Mod 2) = 0) Then
                'is even
                rndNUM = 8
            Else
                rndNUM = 9
                'is odd
            End If
        End If

        If pbOne.Bounds.IntersectsWith(btnBot.Bounds) Then
            pbOne.Top = 200
            PbT.Visible = False
            tmrMove.Stop()
            MsgBox("Press S to Start")
        End If

        Select Case rndNUM
            Case 1
                pbOne.Left -= 2
                pbOne.Top -= 3
            Case 2
                spC += 1
                If ((spC Mod 2) = 0) Then
                    pbOne.Left -= 3
                    pbOne.Top += 2
                Else
                    pbOne.Left -= 5
                    pbOne.Top += 1
                End If
            Case 3
                pbOne.Left += 4
                pbOne.Top += 2
            Case 4
                'pbOne.Left -= 3
                pbOne.Top -= 4
            Case 5
                pbOne.Left += 1
                pbOne.Top -= 5
            Case 6
                pbOne.Left -= 3
                pbOne.Top -= 4
            Case 7
                pbOne.Left += 3
                pbOne.Top += 3
            Case 8
                pbOne.Left -= 3
                pbOne.Top += 2
            Case 9
                pbOne.Left += 4
                pbOne.Top += 2
        End Select

        If pbOne.Bounds.IntersectsWith(btnB1.Bounds) Then
            Fire()
            btnB1.Visible = False
            btnB1.Location = New Point(350, -30)
            PbT.Location = New Point(49, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB2.Bounds) Then
            Fire()
            btnB2.Visible = False
            btnB2.Location = New Point(350, -30)
            PbT.Location = New Point(130, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB3.Bounds) Then
            Fire()
            btnB3.Visible = False
            btnB3.Location = New Point(350, -30)
            PbT.Location = New Point(211, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB4.Bounds) Then
            Fire()
            btnB4.Visible = False
            btnB4.Location = New Point(350, -30)
            PbT.Location = New Point(292, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB5.Bounds) Then
            Fire()
            btnB5.Visible = False
            btnB5.Location = New Point(350, -30)
            PbT.Location = New Point(373, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB6.Bounds) Then
            Fire()
            btnB6.Visible = False
            btnB6.Location = New Point(350, -30)
            PbT.Location = New Point(454, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB7.Bounds) Then
            Fire()
            btnB7.Visible = False
            btnB7.Location = New Point(350, -30)
            PbT.Location = New Point(535, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB8.Bounds) Then
            Fire()
            btnB8.Visible = False
            btnB8.Location = New Point(350, -30)
            PbT.Location = New Point(616, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
        If pbOne.Bounds.IntersectsWith(btnB9.Bounds) Then
            Fire()
            btnB9.Visible = False
            btnB9.Location = New Point(350, -30)
            PbT.Location = New Point(697, 31)
            PbT.Visible = True
            rndNUM = 7
        End If
    End Sub
    Private Sub frmStart_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.P Then
            tmrMove.Stop()
        End If

        If e.KeyCode = Keys.S Then

            tmrMove.Interval = 1
            If count = 0 Then
                stopWatch.Start()
            End If
            tmrMove.Start()
            End If

    End Sub
        Public Sub frmStart_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
            'Form Property KeyPreview needs to be set to True
            '=================================================

            If Asc(e.KeyChar) = 27 Then

            Const message As String = "YES" & "   Exit Program" + vbCrLf + vbNewLine + "NO" & "     Read Directions"
            Const caption As String = "Exit OR Return"

                Dim result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If result = DialogResult.Yes Then
                Application.Exit()
            ElseIf result = DialogResult.No Then
                frmInfo.Show()
                Close()
            End If
            End If

        End Sub

    Private Sub frmStart_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        btnB1.Visible = True
        btnB1.Location = New Point(29, 32)
        btnB2.Visible = True
        btnB2.Location = New Point(110, 32)
        btnB3.Visible = True
        btnB3.Location = New Point(191, 32)
        btnB4.Visible = True
        btnB4.Location = New Point(272, 32)
        btnB5.Visible = True
        btnB5.Location = New Point(353, 32)
        btnB6.Visible = True
        btnB6.Location = New Point(434, 32)
        btnB7.Visible = True
        btnB7.Location = New Point(515, 32)
        btnB8.Visible = True
        btnB8.Location = New Point(596, 32)
        btnB9.Visible = True
        btnB9.Location = New Point(677, 32)

    End Sub

End Class
