﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInfo
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmInfo))
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.lbOne = New System.Windows.Forms.ListBox()
        Me.lblExot = New System.Windows.Forms.Label()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblWelcome.Location = New System.Drawing.Point(141, 10)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(304, 32)
        Me.lblWelcome.TabIndex = 0
        Me.lblWelcome.Text = "Welcome to Breakout"
        '
        'lbOne
        '
        Me.lbOne.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbOne.FormattingEnabled = True
        Me.lbOne.ItemHeight = 25
        Me.lbOne.Location = New System.Drawing.Point(45, 60)
        Me.lbOne.Name = "lbOne"
        Me.lbOne.Size = New System.Drawing.Size(510, 329)
        Me.lbOne.TabIndex = 1
        Me.lbOne.UseTabStops = False
        '
        'lblExot
        '
        Me.lblExot.AutoSize = True
        Me.lblExot.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExot.ForeColor = System.Drawing.SystemColors.Desktop
        Me.lblExot.Location = New System.Drawing.Point(96, 481)
        Me.lblExot.Name = "lblExot"
        Me.lblExot.Size = New System.Drawing.Size(411, 32)
        Me.lblExot.TabIndex = 2
        Me.lblExot.Text = "Press ESC to Close Breakout"
        '
        'btnStart
        '
        Me.btnStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStart.Location = New System.Drawing.Point(191, 412)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(194, 41)
        Me.btnStart.TabIndex = 3
        Me.btnStart.Text = "Start Breakout"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'frmInfo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(592, 537)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.lblExot)
        Me.Controls.Add(Me.lbOne)
        Me.Controls.Add(Me.lblWelcome)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "frmInfo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Breakout"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblWelcome As Label
    Friend WithEvents lbOne As ListBox
    Friend WithEvents lblExot As Label
    Friend WithEvents btnStart As Button
End Class
